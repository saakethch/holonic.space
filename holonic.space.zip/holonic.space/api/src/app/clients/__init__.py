from fastapi import APIRouter

from .groot.germination_counter_api.server import router as germination_router
from .rags.server import router as rags_router
from .dbchat.server import router as dbchat_router
from .tutair.server import router as tutair_router
from ..holonics.api.routes.chat_router import chat_router

router = APIRouter(prefix="/apps") 
router.include_router(germination_router)
router.include_router(rags_router)
router.include_router(dbchat_router)
router.include_router(tutair_router)
router.include_router(chat_router)
