import time
from fastapi import File, UploadFile, APIRouter
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/dbchat",tags=["dbchat"])

@router.get("/ping/")
async def ping():
    return JSONResponse(content={"status": "hello"})
