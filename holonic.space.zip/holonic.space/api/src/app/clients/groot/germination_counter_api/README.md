# Gernimation Counter API

Instructions

1. Open the root directory in the terminal
```
python3 -m venv venv
source ./venv/bin/activate
pip install -r requirements.txt
```

2. Run the Server (API)
```
uvicorn run server:app
```

3. Run the Streamlit App
```
streamlit run app.py
```
