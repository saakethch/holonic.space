from skimage.transform import probabilistic_hough_line
from math import atan2, degrees
import numpy as np
import cv2
import tensorflow as tf
import time
from fastapi import File, UploadFile, APIRouter
from fastapi.responses import JSONResponse

import base64
# app = FastAPI()
router = APIRouter(tags=["groot"])
# Tray cropping function
def eucledian_distance(p0, p1):
    return ((p0[0] - p1[0])**2 + (p0[1] - p1[1])**2)**0.5

def find_intersection(max_left, max_top):
    def get_line_equation(p1, p2):
        x1, y1 = p1
        x2, y2 = p2

        if x1 == x2:  # Vertical line
            return 'vertical', x1
        elif y1 == y2:  # Horizontal line
            return 'horizontal', y1
        else:  # General line
            m = (y2 - y1) / (x2 - x1)
            c = y1 - m * x1
            return 'general', (m, c)

    # Get line equations
    line1_type, line1_val = get_line_equation(*max_left)
    line2_type, line2_val = get_line_equation(*max_top)

    # Find intersection
    if line1_type == 'general' and line2_type == 'general':
        m1, c1 = line1_val
        m2, c2 = line2_val

        if m1 == m2:  # Parallel lines
            print('Parallel lines')
            return None

        xi = (c2 - c1) / (m1 - m2)
        yi = m1 * xi + c1
        return xi, yi
    elif line1_type == 'vertical' and line2_type == 'general':
        m2, c2 = line2_val
        xi = line1_val
        yi = m2 * xi + c2
        return xi, yi
    elif line1_type == 'general' and line2_type == 'vertical':
        m1, c1 = line1_val
        xi = line2_val
        yi = m1 * xi + c1
        return xi, yi
    elif line1_type == 'horizontal' and line2_type == 'general':
        m2, c2 = line2_val
        yi = line1_val
        xi = (yi - c2) / m2
        return xi, yi
    elif line1_type == 'general' and line2_type == 'horizontal':
        m1, c1 = line1_val
        yi = line2_val
        xi = (yi - c1) / m1
        return xi, yi
    elif line1_type == 'horizontal' and line2_type == 'vertical':
        yi = line1_val
        xi = line2_val
        return xi, yi
    elif line1_type == 'vertical' and line2_type == 'horizontal':
        xi = line1_val
        yi = line2_val
        return xi, yi
    else:
        # Both lines are horizontal or both are vertical - no intersection or infinite intersections
        print(line1_type, line2_type)
        return None

def crop_tray(img):
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (7, 7), 0)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = probabilistic_hough_line(edges, threshold=5, line_length=15, line_gap=3)

    right_lines = []
    max_right_len = 0
    max_right = [[0,0], [0,0]]

    left_lines = []
    max_left_len = 0
    max_left = [[0,0], [0,0]]

    top_lines = []
    max_top_len = 0
    max_top = [[0,0], [0,0]]

    bottom_lines = []
    max_bottom_len = 0
    max_bottom = [[0,0], [0,0]]

    for line in lines:
        p0, p1 = line
        dist = eucledian_distance(p0, p1)
        angle = abs(degrees(atan2(p1[1] - p0[1], p1[0] - p0[0])))
        if angle > 85 and angle < 95:
            if p0[0] < img.shape[1]/2:
                if dist >= max_left_len:
                    max_left_len = dist
                    max_left = line
                left_lines.append(line)
            else:
                if dist >= max_right_len:
                    max_right_len = dist
                    max_right = line
                right_lines.append(line)  
        elif (angle > 175 and angle < 185) or (angle >= 0 and angle < 10):
            if p0[1] < img.shape[0]/2:
                if dist >= max_top_len:
                    max_top_len = dist
                    max_top = line
                top_lines.append(line)
            else:
                if dist >= max_bottom_len:
                    max_bottom_len = dist
                    max_bottom = line
                bottom_lines.append(line)
                
    point1 = find_intersection(max_left, max_top)
    point2 = find_intersection(max_right, max_top)
    point3 = find_intersection(max_left, max_bottom)
    point4 = find_intersection(max_right, max_bottom)
    
    input_points = np.float32([point1, point2, point3, point4])
    width, height = 280, 440
    converted_points = np.float32([[0, 0], [width, 0], [0, height], [width, height]])
    
    matrix = cv2.getPerspectiveTransform(input_points, converted_points)
    wrap = cv2.warpPerspective(img, matrix, (width, height))

    return wrap

def cuts(img):
    cropped = img[20:-20, :]
    cols = np.linspace(0, cropped.shape[1], 7)
    rows = np.linspace(0, cropped.shape[0], 9)

    pots = []
    for i in range(8):
        for j in range(6):
            pots.append(cropped[int(rows[i]):int(rows[i+1]), int(cols[j]):int(cols[j+1])])
    
    return pots

def count_germinations_ml(img, model):
    pots = cuts(crop_tray(img))
    classes = ['germinated', 'not germinated']
    height, width, _ = pots[0].shape
    grid_cols = 6
    grid_rows = 8
    canvas = np.zeros((height * grid_rows, width * grid_cols, 3), dtype=np.uint8)
    germinations = 0
    for i in range(len(pots)):
        img = pots[i]
        img_pre = cv2.resize(img, (224, 224))
        img_pre = img_pre/255.
        pred = model.predict(tf.expand_dims(img_pre, axis=0), verbose=0)
        pred_class = classes[int(tf.round(pred))]
        conf = pred[0][0] * 100 if pred[0][0] > 0.5 else(1 - pred[0][0]) * 100
        if(pred_class == 'germinated'):
            cv2.putText(img, f'{conf:.2f}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
            germinations += 1
        else:
            cv2.putText(img, f'{conf:.2f}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
        x = (i % grid_cols) * width
        y = (i // grid_cols) * height
        
        resized = cv2.resize(img, (width, height))
        canvas[y:y+height, x:x+width] = resized
            
    germination_percentage = round(germinations/len(pots) * 100, 2)
    
    canvas = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB)
    
    return canvas, germinations, germination_percentage


# testing the difference between the two methods

# tot_time = 0
# images = 0
# for impath in os.listdir('testing/'):
#     original = crop_tray(f'testing/{impath}')
#     images += 1
#     print(impath)
#     start = time.perf_counter()
#     model = tf.keras.models.load_model('GerminationNetV1.h5')
#     img, germination_count, germination_percentage = count_germinations_ml(f'testing/{impath}', model)
#     end = time.perf_counter() - start
#     tot_time += end
#     print("Time: ", end)
#     plt.figure(figsize=(20, 15))
#     plt.subplot(1, 2, 1)
#     plt.imshow(cv2.cvtColor(original, cv2.COLOR_BGR2RGB))
#     plt.title('Original')
#     plt.subplot(1, 2, 2)
#     plt.imshow(img)
#     plt.title(f'Germination Count: {germination_count}, Germination Percentage: {germination_percentage:.2f}, time: {end}s%')
#     plt.savefig(f'test_op/preds/{impath}')

# print(f"Average time: {tot_time/images}s, total time: {tot_time}s")
@router.get("/ping/")
async def ping():
    return JSONResponse(content={"status": "hello"})


import h5py 

@router.post("/germination_count/")
async def germination_count(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        nparr = np.fromstring(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        # f = h5py.File('/code/app/clients/groot/germination_counter_api/GerminationNetV1.h5', 'r')
        model = tf.keras.models.load_model(f"/code/app/clients/groot/germination_counter_api/GerminationNetV1.h5")
        annotated_image, germination_count, germination_percentage = count_germinations_ml(img, model)
        
        _, encoded_img = cv2.imencode('.png', annotated_image)
        encoded_img = base64.b64encode(encoded_img).decode('utf-8')
        return JSONResponse(content={"status": "success", "germination_percentage": germination_percentage, "germination_count": germination_count, "annotated_image": encoded_img})
    except Exception as e:
        return JSONResponse(content={"status": "error", "message": str(e)})

# @router.post("/rag/")
# async def rag():
#     try:
        
#         return JSONResponse(content={"status": "success", "germination_percentage": germination_percentage, "germination_count": germination_count, "annotated_image": encoded_img})
#     except Exception as e:
#         return JSONResponse(content={"status": "error", "message": str(e)})