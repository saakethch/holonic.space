import time
from fastapi import File, UploadFile, APIRouter
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/rags",tags=["rags"])

@router.get("/ping/")
async def ping():
    return JSONResponse(content={"status": "hello"})
