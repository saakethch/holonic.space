import time
from fastapi import File, UploadFile, APIRouter
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/tutair",tags=["tutair"])

@router.get("/ping/")
async def ping():
    return JSONResponse(content={"status": "hello"})
