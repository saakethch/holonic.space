from arq.connections import ArqRedis

pool: ArqRedis | None = None
