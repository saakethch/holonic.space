from phi.storage.assistant.postgres import PgAssistantStorage
# from core.db.database import local_session
# from db.session import db_url
from phi.docker.app.postgres import PgVectorDb

# vector_db = PgVectorDb(
#     pg_user="postgres",
#     pg_password="1234",
#     pg_database="db",
# )
# local_session = vector_db.get_db_connection_local()
pdf_assistant_storage = PgAssistantStorage(
    db_url="postgresql+psycopg://postgres:1234@db:5432/postgres",
    table_name="pdf_assistant",
)

image_assistant_storage = PgAssistantStorage(
    db_url="postgresql+psycopg://postgres:1234@db:5432/postgres",
    table_name="image_assistant",
)

website_assistant_storage = PgAssistantStorage(
    db_url="postgresql+psycopg://postgres:1234@db:5432/postgres",
    table_name="website_assistant",
)
 