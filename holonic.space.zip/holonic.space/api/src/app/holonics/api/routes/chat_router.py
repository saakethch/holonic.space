from fastapi import APIRouter

from .assistants import assistants_router
# from .hn import hn_router

chat_router = APIRouter(prefix="/chat")
chat_router.include_router(assistants_router)
# chat_router.include_router(hn_router)
