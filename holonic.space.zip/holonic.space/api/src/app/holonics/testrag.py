from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

# Configuration for the first engine and session
DATABASE_URL_1 = f"postgresql+asyncpg://postgres:1234@db:5432/postgres"

async_engine_1 = create_async_engine(DATABASE_URL_1, echo=False, future=True)
local_session_1 = sessionmaker(bind=async_engine_1, class_=AsyncSession, expire_on_commit=False)

async def async_get_db_1() -> AsyncSession:
    async with local_session_1() as db:
        yield db
        await db.commit()

# Configuration for the second engine and session (can be the same or different settings)
DATABASE_URL_2 = f"postgresql+asyncpg://postgres:1234@db:5432/postgres"

async_engine_2 = create_async_engine(DATABASE_URL_2, echo=False, future=True)
local_session_2 = sessionmaker(bind=async_engine_2, class_=AsyncSession, expire_on_commit=False)

async def async_get_db_2() -> AsyncSession:
    async with local_session_2() as db:
        yield db
        await db.commit()

async_get_db_1()
async_get_db_2()
