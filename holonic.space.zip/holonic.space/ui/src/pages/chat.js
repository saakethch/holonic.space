import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

function Chat() {
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const chatEndRef = useRef(null);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    const requestBody = {
      message: message,
      // Include other necessary body parameters
    };

    setChatHistory((prevHistory) => [...prevHistory, { role: 'user', content: message }]);
    setMessage('');

    const response = await axios.post('https://holonic.space/api/apps/chat/assistants/chat', requestBody, {
      responseType: 'stream'
    });

    // Handling streamed data
    const reader = response.data.getReader();
    const decoder = new TextDecoder();

    reader.read().then(function processText({ done, value }) {
      if (done) {
        console.log("Stream complete");
        return;
      }
      const chunk = decoder.decode(value, { stream: true });
      // Process chunk (a part of the response)
      console.log(chunk); // Implement logic to update chatHistory based on your streaming data format

      return reader.read().then(processText);
    });
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);
  
  return (
    <div className="chat-container">
      <div className="chat-history">
        {chatHistory.map((chat, index) => (
          <div key={index} className={`chat-message ${chat.role}`}>
            {chat.content}
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>
      <form className="chat-form" onSubmit={sendMessage}>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message here..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};

export default Chat;
