import Link from 'next/link';
import Image from "next/image";
// Assuming you're using the Inter font from 'next/font/google'
import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  return (
    <div>
      <h1>Welcome to Holonic . Space</h1>
      <nav>
        <ul>
          <li><Link href="/about"><a>About Us</a></Link></li>
          <li><Link href="/profile"><a>Profile</a></Link></li>
          <li><Link href="/login"><a>Login</a></Link></li>
          <li><Link href="/register"><a>Register</a></Link></li>
          <li><Link href="/chat"><a>Chat</a></Link></li>
          <li><Link href="/upload"><a>Upload Image</a></Link></li> {/* Add this line */}
        </ul>
      </nav>
    </div>
  );
}
