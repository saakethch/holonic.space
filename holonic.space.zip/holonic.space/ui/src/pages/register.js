import { useState } from 'react';
import axios from 'axios';

function Register() {
    const [userData, setUserData] = useState({
        username: '',
        email: '',
        name:'',
        password: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserData({ ...userData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('/api/v1/user', userData);
            console.log('Registration Success:', response.data);
            // Handle success
        } catch (error) {
            console.error('Registration Error:', error.response.data);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Name:</label>
                <input
                    name="name"
                    type="text"
                    value={userData.name}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Username:</label>
                <input
                    name="username"
                    type="text"
                    value={userData.username}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Email:</label>
                <input
                    name="email"
                    type="email"
                    value={userData.email}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Password:</label>
                <input
                    name="password"
                    type="password"
                    value={userData.password}
                    onChange={handleChange}
                />
            </div>
            <button type="submit">Register</button>
        </form>
    );
}

export default Register;
