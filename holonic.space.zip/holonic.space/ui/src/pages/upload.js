import { useState } from 'react';
import Image from "next/image";
import { useRouter } from 'next/router';

export default function Upload() {
  const [image, setImage] = useState(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState('');
  const [germinationData, setGerminationData] = useState({});
  const router = useRouter();

  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('file', image);

    try {
      const response = await fetch('https://holonic.space/api/apps/germination_count/', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();

      if (data.status === 'success') {
        setGerminationData(data);
        const blob = new Blob([Uint8Array.from(atob(data.annotated_image), c => c.charCodeAt(0))], {type: 'image/png'});
        const url = URL.createObjectURL(blob);
        setUploadedImageUrl(url);
      } else {
        console.error('Failed to upload image');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
    }
  };

  return (
    <div>
      <h1>Upload Image</h1>
      <form onSubmit={handleSubmit}>
        <input type='file' onChange={handleImageChange} />
        <button type='submit'>Upload</button>
      </form>
      {uploadedImageUrl && (
        <>
          <h2>Uploaded Image:</h2>
          <img src={uploadedImageUrl} alt="Annotated" />
        </>
      )}
      {germinationData.germination_percentage && (
        <div>
          <p>Germination Percentage: {germinationData.germination_percentage}%</p>
          <p>Germination Count: {germinationData.germination_count}</p>
        </div>
      )}
    </div>
  );
}
